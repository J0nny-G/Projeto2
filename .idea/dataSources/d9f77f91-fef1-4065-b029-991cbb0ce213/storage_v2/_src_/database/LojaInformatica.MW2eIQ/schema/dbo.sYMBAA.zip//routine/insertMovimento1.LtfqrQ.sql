create procedure insertMovimento1
	@idconta int,
	@valor decimal(10,2),
	@tipomovimento char(1),
	@data date
as
begin
	insert into movimento(idconta,valor,tipomovimento,data)
	values (@idconta,@valor,@tipomovimento,@data);

	update conta
	set tipoconta = case
			when saldo < 250 then 'R'
			when saldo >= 250 and saldo <= 5000 then 'E'
			when saldo > 5000 then 'P'
		end
		where idconta = @idconta;
end;
go

